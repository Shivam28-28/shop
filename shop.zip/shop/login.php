
<?php
// Configuration
$db_host = 'localhost';
$db_username = 'root';
$db_password = '';
$db_name = 'shop_shivam'; // Changed to shop_shivam

// Create connection
$conn = new mysqli($db_host, $db_username, $db_password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: ". $conn->connect_error);
}

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query to check if username and password exist
    $sql = "SELECT * FROM admins WHERE Username = ?";
    $stmt = $conn->prepare($sql);

    // Check if prepare() returned false
    if ($stmt === false) {
        die("Error preparing the statement: " . $conn->error);
    }

    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    $stmt->close();
    $conn->close();

    if($user['Username'] == $username && $user['Password'] == $password)
    {
        // Save the login credentials
        setcookie("username", $username, time() + (86400 * 30)); // 86400 = 1 day
        setcookie("password", $password, time() + (86400 * 30)); // 86400 = 1 day
        echo "Login credentials saved successfully!";
        // Redirect to the dashboard or any other page
        header("Location: login.php");
        exit();
    }else{
        $error = "Invalid username or password";
        // Redirect to the home page with the alert message
        echo "<script type='text/javascript'>
                alert('$error');
                window.location.href = '/shop';
                </script>";
        exit();
    }
}
// // Logout.php

// // Check if the user is logged in

// if (isset($_COOKIE['username']) && isset($_COOKIE['password'])) {
//     // Delete the cookies
//     setcookie("username", "", time() - 3600);
//     setcookie("password", "", time() - 3600);

//     // Redirect to the home page
//     header("Location: ");
//     exit();
// } else {
//     // Redirect to the home page if the user is not logged in
//     header("Location: ");
//     exit();
// }
?>

<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <style>
        /* Basic styling for demonstration */
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        form {
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
            text-align: center;
        }
        input {
            margin-bottom: 10px;
            padding: 8px;
            width: calc(100% - 16px);
        }
        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            border: none;
            cursor: pointer;
            width: 100%;
        }
        button:hover {
            opacity: 0.8;
        }
    </style>
</head>
<body>
    <form action="login.php" method="POST">
        <h2>Admin Login</h2>
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Login</button>
    </form>
</body>
</html>


------------------------------------------------------------ -->







<!DOCTYPE html>
<html>
<head>
    <title>Shivam Shop</title>
    <style>
body {
    font-family: Arial, sans-serif;
}

.header {
    background-color: cornflowerblue;
    padding: 20px;
    text-align: center;
    position: relative;
}

.headerimage {
    left: 20px;
    top: 10px;
    position: absolute;
}

.cart-icon {
    position: absolute;
    top: 20px;
    right: 20px;
    font-size: 48px;
    color: red;
    cursor: pointer;
}

.cart-count {
    position: absolute;
    top: 20px;
    right: 20px;
    font-size: 24px;
    color: white;
    background-color: red;
    border-radius: 50%;
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.content {
    text-align: center;
    margin-top: 20px;
}

.image {
    text-align: left;
    margin-top: 2%;
    padding-left: 3%;
}

.card {
    display: inline-block;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
    max-width: 300px;
    margin: 1%;
    text-align: center;
    font-family: Arial;
}

.price {
    color: grey;
    font-size: 22px;
}

.card button {
    border: none;
    outline: 0;
    padding: 1%;
    color: white;
    background-color: #000;
    text-align: center;
    cursor: pointer;
    width: 100%;
    font-size: 18px;
}

.card button:hover {
    opacity: 0.7;
}

img {
    width: 80%;
    height: auto;
}

.modal {
    display: none;
    position: fixed;
    z-index: 1;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgb(0,0,0);
    background-color: rgba(0,0,0,0.4);
    padding-top: 60px;
}

.modal-content {
    background-color: #fefefe;
    margin: 5% auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
}

.close {
    color: #aaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: black;
    text-decoration: none;
    cursor: pointer;
}

.payment-method {
    margin-top: 20px;
}

.payment-method h3 {
    margin-bottom: 10px;
}

.payment-method label {
    display: block;
    margin-bottom: 5px;
}

.payment-method input[type="text"], 
.payment-method input[type="number"], 
.payment-method input[type="email"] {
    width: calc(100% - 20px);
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

.payment-method select {
    width: 100%;
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

.payment-method button {
    width: 100%;
    padding: 10px;
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 18px;
}

.payment-method button:hover {
    background-color: #45a049;
}

#qr-code {
    max-width: 100%;
    height: auto;
    display: none; /* Hide initially, if you want to show it dynamically */
    margin-top: 10px; /* Adjust spacing as needed */
}

.footer {
  background-color: #333;
  color: #fff;
  padding: 20px;
  text-align: center;
}

.footer-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
}

.footer-columns {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
}

.footer-column {
  flex-basis: 25%;
  margin: 20px;
}

.footer-column h4 {
  margin-top: 0;
}

.footer-column ul {
  list-style: none;
  padding: 0;
  margin: 0;
}

.footer-column li {
  margin-bottom: 10px;
}

.footer-column a {
  color: #fff;
  text-decoration: none;
}

.footer-column a:hover {
  color: #ccc;
}

.footer-copyright {
  background-color: #444;
  padding: 10px;
  text-align: center;
  color: #fff;
}

.footer-copyright p {
  margin: 0;
}

.footer-container::after {
  content: "";
  clear: both;
  display: table;
}

.footer-column:nth-child(4) {
  text-align: left;
}

.footer-column:nth-child(4) form {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 10px
}

    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
    <div class="header">
        <h1>Shivam Shop</h1>
        <i class="fas fa-shopping-cart cart-icon" id="cart-icon"></i>
        <div class="cart-count" id="cart-count">0</div>
        
    </div>  

    <div class="headerimage">
    <img src="images/Blisslogo.jpg" alt="Bliss Logo">
    </div>
    <div class="content">
        <h2>Our Products</h2>
    </div>
    <div class="image">
        <div class="card">
            <img src="images/Divine_Mockup.jpg" alt="Divine Mockup">
            <p class="price">$19.99</p>
            <button>Add to Cart</button>
        </div>
        <div class="card">
            <img src="images/Chandan_Mockup.jpg" alt="Chandan Mockup">
            <p class="price">$19.99</p>
            <button>Add to Cart</button>
        </div>
        <div class="card">
            <img src="images/Aqua.jpg" alt="Aqua Mockup">
            <p class="price">$19.99</p>
            <button>Add to Cart</button>
        </div>
        <div class="card">
            <img src="images/Golden_Mockup.jpg" alt="Golden Mockup">
            <p class="price">$19.99</p>
            <button>Add to Cart</button>
        </div>
        <div class="card">
            <img src="images/Infinite_Mockup.jpg" alt="Infinite Mockup">
            <p class="price">$19.99</p>
            <button>Add to Cart</button>
        </div>
        <div class="card">
            <img src="images/KesarChandan_Mockup.jpg" alt="KesarChandan Mockup">
            <p class="price">$19.99</p>
            <button>Add to Cart</button>
        </div>
        <div class="card">
            <img src="images/Mogra_Mockup.jpg" alt="Mogra Mockup">
            <p class="price">$19.99</p>
            <button>Add to Cart</button>
        </div>
        <div class="card">
            <img src="images/Kesar Kasturi Mockup.jpg" alt="Kesar Mockup">
            <p class="price">$19.99</p>
            <button>Add to Cart</button>
        </div>
        <div class="card">
            <img src="images/Last 1.jpg" alt="Last Image">
            <p class="price">$34.99</p>
            <button>Add to Cart</button>
        </div>
        <div class="card">
            <img src="images/Last 2 1.jpg" alt="Last Image">
            <p class="price">$34.99</p>
            <button>Add to Cart</button>
        </div>
    </div>

    <!-- The Modal -->
    <div id="cart-modal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Your Cart</h2>
            <ul id="cart-items"></ul>
            <h3 id="grand-total">Total: $0.00</h3>
            <div class="payment-method">
    <h3>Payment Method</h3>
    <form id="payment-form">
        <label for="name">Name on Card</label>
        <input type="text" id="name" name="name" required>

        <label for="card-number">Card Number</label>
        <input type="number" id="card-number" name="card-number" required>

        <label for="expiry">Expiry Date</label>
        <input type="text" id="expiry" name="expiry" placeholder="MM/YY" required>

        <label for="cvv">CVV</label>
        <input type="number" id="cvv" name="cvv" required>

        <label for="email">Email</label>
        <input type="email" id="email" name="email" required>

        <!-- Add payment method options (e.g., PayPal, Stripe, etc.) -->
        <label for="payment-method">Payment Method</label>
        <select id="payment-method" name="payment-method">
            <option value="paypal">PayPal</option>
            <option value="stripe">Stripe</option>
            <!-- Add more payment method options as needed -->
        </select>

        <button type="submit">Pay Now</button>
    </form>
</div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            let cartCount = 0;
            const cartCountElement = document.getElementById('cart-count');
            const cartIcon = document.getElementById('cart-icon');
            const modal = document.getElementById('cart-modal');
            const closeModal = document.getElementsByClassName('close')[0];
            const cartItems = document.getElementById('cart-items');
            const grandTotalElement = document.getElementById('grand-total');
            const paymentForm = document.getElementById('payment-form');
            const cart = [];

            document.querySelectorAll('.card button').forEach((button, index) => {
                button.addEventListener('click', function() {
                    cartCount++;
                    cartCountElement.textContent = cartCount;

                    const itemCard = button.parentElement;
                    const itemName = itemCard.querySelector('img').alt;
                    const itemPrice = parseFloat(itemCard.querySelector('.price').textContent.replace('$', ''));

                    cart.push({ name: itemName, price: itemPrice });
                    updateCart();
                });
            });

            cartIcon.addEventListener('click', function() {
                modal.style.display = 'block';
            });

            closeModal.onclick = function() {
                modal.style.display = 'none';
            };

            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = 'none';
                }
            };

            paymentForm.addEventListener('submit', function(event) {
    event.preventDefault();
    const formData = new FormData(paymentForm);
    const email = formData.get('email');
    const paymentMethod = formData.get('payment-method');

    // Process payment based on selected payment method
    if (paymentMethod === 'paypal') {
        // PayPal payment processing logic here
        //...
    } else if (paymentMethod === 'stripe') {
        // Stripe payment processing logic here
        //...
    } else {
        console.error('Unsupported payment method');
        return;
    }

    // Calculate total price of items in the cart
    let total = 0;
    cart.forEach(item => {
        total += item.price;
    });

    // Send email after payment processing
    fetch(' ', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            cart: cart, // Replace with your cart data
            total: total, // Pass the calculated total here
            email: email // Use the email obtained from form
        })
    })
   .then(response => response.text())
   .then(result => {
        console.log('Payment processed successfully and email sent:', result);
        alert('Payment processed successfully and email sent!');
        // Reset cart and update UI as needed
    })
   .catch(error => {
        console.error('Error:', error);
        alert('Error processing payment or sending email. Please try again.');
    });

    // Show QR code after form submission
    document.getElementById('qr-code').style.display = 'block';
});

            function updateCart() {
                cartItems.innerHTML = '';
                let total = 0;
                cart.forEach(item => {
                    const li = document.createElement('li');
                    li.textContent = `${item.name} - $${item.price.toFixed(2)}`;
                    cartItems.appendChild(li);
                    total += item.price;
                });
                grandTotalElement.textContent = `Total: $${total.toFixed(2)}`;
            }
        });
    </script>

<div class="footer">
        <!-- Footer -->
        <footer class="footer">
  <div class="footer-container">
    <div class="footer-columns">
      <div class="footer-column">
        <h4>About Us</h4>
        <p>We're a team of passionate individuals who love creating amazing products. Our mission is to provide high-quality, sustainable, and affordable products to our customers.</p>
        <ul>
          <li><a href="#">Our Story</a></li>
          <li><a href="#">Meet the Team</a></li>
          <li><a href="#">Careers</a></li>
        </ul>
      </div>
      <div class="footer-column">
        <h4>Help & Support</h4>
        <p>Need help with something? We're here to assist you.</p>
        <ul>
          <li><a href="#">FAQs</a></li>
          <li><a href="#">Contact Us</a></li>
          <li><a href="#">Return Policy</a></li>
        </ul>
      </div>
      <div class="footer-column">
        <h4>Stay Connected</h4>
        <p>Follow us on social media to stay up-to-date with our latest news and promotions.</p>
        <ul>
          <li><a href="https://www.facebook.com/" class="fab fa-facebook-f"></a></li>
          <li><a href="#" class="fab fa-twitter"></a></li>
          <li><a href="#" class="fab fa-instagram"></a></li>
        </ul>
      </div>
      <div class="footer-column">
        <h4>Newsletter</h4>
        <p>Sign up for our newsletter to receive exclusive offers and updates.</p>
        <form>
          <input type="email" placeholder="Enter your email address">
          <button type="submit">Subscribe</button>
        </form>
      </div>
    </div>
    <div class="footer-copyright">
      <p>&copy; 2023 Shivam Shop. All rights reserved.</p>
    </div>
  </div>
</footer>
    </div> 
</body>
</html>

