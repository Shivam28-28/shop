const express = require('express');
const nodemailer = require('nodemailer');
const bodyParser = require('body-parser');
const cors = require('cors');
const session = require('express-session');
const path = require('path');

const app = express();
const portAdmin = 84; // Port for admin login
const portEmail = 82; // Port for sending email

// Middleware
app.use(bodyParser.json());
app.use(cors());
app.use(session({
    secret: 'secret-key',
    resave: false,
    saveUninitialized: true
}));

// Nodemailer transporter setup
const transporter = nodemailer.createTransport({
    host: '139.99.136.113',
    port: 2525, // Replace with your SMTP port (usually 587 for TLS, 465 for SSL)
    secure: false, // Set to true if you are using SSL (port 465), otherwise false
    auth: {
        user: 'new1smtpemonew', // Replace with your SMTP username
        pass: 'riYSa4dsjcHs' // Replace with your SMTP password
    },
    tls: {
        rejectUnauthorized: false // This is optional, used for self-signed certificates
    }
});

// Endpoint to send email
app.post('/send-email', (req, res) => {
    const { cart, total, email } = req.body;

    const mailOptions = {
        from: 'info@infisms.com', // Sender email address
        to: 'shivamsharmabsr456@gmail.com', // Recipient email address (replace with your recipient)
        subject: 'New Order Received',
        text: `New order received.\n\nItems:\n${cart.map(item => `${item.name}: $${item.price}`).join('\n')}\n\nTotal: $${total}`
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.error('Error sending email:', error);
            return res.status(500).send(error.toString());
        }
        console.log('Email sent:', info.response);
        res.status(200).send('Email sent: ' + info.response);
    });
});

// Mock user data for demonstration purposes
const adminUser = {
    username: 'admin',
    password: 'admin123' // In a real application, use hashed passwords
};

// Handle admin login
app.post('/admin-login', (req, res) => {
    const { username, password } = req.body;
    
    // Assuming adminUser is defined somewhere in your application
    if (username === adminUser.username && password === adminUser.password) {
        req.session.isAuthenticated = true;
        res.json({ success: true });
    } else {
        res.status(401).json({ success: false, message: 'Invalid username or password' });
    }
});


// Middleware to protect admin routes
function isAuthenticated(req, res, next) {
    if (req.session.isAuthenticated) {
        return next();
    } else {
        res.status(401).send('Unauthorized');
    }
}

// Example of a protected admin route
app.get('/admin-panel', isAuthenticated, (req, res) => {
    res.sendFile(path.join(__dirname, 'admin-panel.html')); // Ensure admin-panel.html is in the same directory as this script
});

// Start both servers
app.listen(portAdmin, () => {
    console.log(`Admin server is running on http://localhost:${portAdmin}`);
});

app.listen(portEmail, () => {
    console.log(`Email server is running on http://localhost:${portEmail}`);
});


