<?php
if(isset($_GET['error']))
{
    $error = $_GET['error'];
    echo "<script type='text/javascript'>
                alert('$error');
                window.location.href = '/shop';
              </script>";
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <style>
        /* Basic styling for demonstration */
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 10px;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 80vh;
        }
        form {
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 160px rgba(0, 0, 0, 0.1);
            width: 350px;
            text-align: center;
        }
        input {
            margin-bottom: 30px;
            padding: 8px;
            width: calc(100% - 16px);
        }
        button {
            background-color: #4CAF50;
            color: white;
            padding: 15px;
            border: none;
            cursor: pointer;
            width: 100%;
        }
        button:hover {
            opacity: 0.8;
        }
        .error {
            color: #red;
            font-size: 12px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <form action="login.php" method="POST">
        <h2>Admin Login</h2>
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Login</button>
        <?php if (isset($error)) { ?>
            <div class="error"><?= $error ?></div>
        <?php } ?>
    </form>
</body>
</html>